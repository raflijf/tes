const btnopsi = document.querySelector('.navbar .navigasi li button')
btnopsi.addEventListener('click', () => {
    const opsi = document.getElementById('opsi')
    opsi.classList.toggle('toggle')
})

const humburgermenu = document.getElementById("humburgermenu")
humburgermenu.addEventListener('click', () => {
    const menu = document.getElementById('menu')
    menu.classList.toggle('toggle-humburgermenu')
    // const tamplate = document.getElementById('tamplate')
    // tamplate.classList.toggle('toggle-humburgermenu')
})
